def gg():
 return(print('Hello World'))
gg()
def ll_a():
    pass
print(ll_a)